/*
    Copyright (C) 2016, 2020 Innovate-jex
    All rights reserved.

    Use of this source code is governed by a BSD-style license that can be found
    in the LICENSE file.
*/
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#include "benchmark/benchmark.h"
#include "tiny_dnn/tiny_dnn.h"

#include "bm_global_avepool.h"
using namespace tiny_dnn::benchmarks;

BENCHMARK_MAIN();
p